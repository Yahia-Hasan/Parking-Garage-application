package projest2;

public class Owner implements person{
	public String name(String name)
	{return name;}
	public String pass(String pass)
	{return pass;}

}