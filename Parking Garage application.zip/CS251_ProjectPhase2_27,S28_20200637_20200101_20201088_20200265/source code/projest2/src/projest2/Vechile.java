package projest2;


public class Vechile {
	private String modelName;
	private int id;
	private int modelYear;
	private float width;
	private float depth;
	private Vehicle_Type type;
	
	public void setModelName(String name)
	{
		modelName=name;
	}
	public void settype(Vehicle_Type t)
	{
		type=t;
	}
	public void setId(int ID)
	{
		id=ID;
	}
	public void setModelYear(int year)
	{
		modelYear=year;
	}
	public void setWidth(float wid)
	{
       width=wid;
	}
	public void setDepth(float dep)
	{
		depth=dep;
	}
	public String getModelName()
	{
		return modelName;
	}
	public int getId()
	{
		return id;
	}
	public Vehicle_Type gettype()
	{
		return type;
	}
	public int getModelYear()
	{
		return modelYear;
	}
	public float getWidth()
	{
		return width;
	}
	public float getDepth()
	{
		return depth;
	}
   public void addNewVechile(String name, int ID, int year, float wid, float dep,Vehicle_Type t)
   {
	   type=t;
	   modelName=name;
	   id=ID;
	   modelYear=year;
	   width=wid;
	   depth=dep;
   }

}
