package projest2;
import java.util.Scanner;
public class parking_slots {
		private float slotWidth;
		private float slotDepth;
		public float slots[][];
		public int s;
	    private Scanner keyboard;

		public parking_slots()
		{
			int size;
			System.out.println ("how many slots");
			keyboard = new Scanner (System.in);
			size = keyboard.nextInt();
			s=size;
			slots=new float[size][];
			for(int i=0;i<size;i++)
			{
				slots[i]=new float [3];
			}
			for(int i=0;i<size;i++)
			{   int j=i+1;
				System.out.println ("Enter slotWidth of slot "+j);
				slotWidth = keyboard.nextInt();
				keyboard = new Scanner (System.in);
				System.out.println ("Enter slotDepth of slot "+j);
	            slotDepth = keyboard.nextInt();
				slots[i][0]=slotWidth;
				slots[i][1]=slotDepth;
				slots[i][2]=0;
				
			}
			
		}

		public void freeSlot(int slotPlace)
		{
			slots[slotPlace][2]=0;
		}

	}


