package projest2;

import java.time.Duration;
import java.time.Instant;

public class Parking_fees {
public long fees(Instant start,Instant end,parking_slots sl,Total_Income T)
{
	 Duration timeElapsed = Duration.between(start,end); 
	 long Hours =timeElapsed.toHours();
	 if(Hours<1)
	 {Hours=1;}
	 T.totalIncome(5*Hours);
	 return (5*Hours);
}
}
