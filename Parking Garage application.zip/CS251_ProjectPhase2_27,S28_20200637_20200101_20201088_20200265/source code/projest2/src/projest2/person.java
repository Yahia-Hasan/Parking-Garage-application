package projest2;

public interface person {
	public String name(String name);
	public String pass(String pass);


}
