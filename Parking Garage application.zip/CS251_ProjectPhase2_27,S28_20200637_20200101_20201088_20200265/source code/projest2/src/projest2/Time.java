package projest2;
import java.time.Instant;
public interface Time {
	public Instant setTime();

}
