package projest2;
public class Best_fit_slot implements Select_configration{
public int pick_slot(float width,float depth,parking_slots sl,Total_Income T)
{
	int k = 0;
	float slo[][];
	slo=new float[sl.s][];
	for(int i=0;i<sl.s;i++)
	{
		slo[i]=new float [3];
	}
   	for(int i=0,j=0;i<sl.s;i+=1)
   	{  
   		if(width<=sl.slots[i][0]&&depth<=sl.slots[i][1])
   		{
   			slo[j][0]=sl.slots[i][0];
   			slo[j][1]=sl.slots[i][1];
   			slo[j][2]=sl.slots[i][2];
   			j++;k++;

   		}
   	}
   	for (int i = 0; i < k; i++)   
   	{  
   	for (int j = i + 1; j < k; j++)   
   	{  
   	float tmp = 0;  
   	if (slo[i][0] > slo[j][0])   
   	{  
   	tmp = slo[i][0];  
   	slo[i][0] = slo[j][0];  
   	slo[j][0] = tmp;  
   	tmp = slo[i][1];  
   	slo[i][1] = slo[j][1];  
   	slo[j][1] = tmp; 
   	}  
   	}
   	}
   	k=0;
   	for(int i=0;i<sl.s;i+=1)
   	{  
   		if(slo[0][0]==sl.slots[i][0]&&slo[0][1]==sl.slots[i][1])
   		{
              k=i;
              sl.slots[i][2]=1;
              T.totalcars();
              break;
   		}
   	}

   	return k+1;
}
}
