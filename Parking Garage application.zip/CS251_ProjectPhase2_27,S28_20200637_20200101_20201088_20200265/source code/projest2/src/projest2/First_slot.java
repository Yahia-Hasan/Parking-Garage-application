package projest2;

public class First_slot implements Select_configration{
public int pick_slot(float width,float depth,parking_slots sl,Total_Income T)
{
	int k = 0;
   	for(int i=0;i<sl.s;i+=1,k++)
   	{  
   		if(width<=sl.slots[i][0]&&depth<=sl.slots[i][1])
   		{
   			sl.slots[i][2]=1;
   			T.totalcars();
   			break;
   		}
   	}
   	return k+1;
}
}
