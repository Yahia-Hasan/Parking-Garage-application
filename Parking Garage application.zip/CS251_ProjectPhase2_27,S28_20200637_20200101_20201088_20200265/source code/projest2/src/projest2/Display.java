package projest2;
public class Display {

	public void availableSlots(parking_slots obj)
	{
		for(int i=0;i<obj.s;i++)
		 {
			if(obj.slots[i][2]==0)
		    {int j=i+1;
			 System.out.println("Slot ID:"+j);
			 System.out.println("Slot Width: "+obj.slots[i][0]);
			 System.out.println("Slot Depth: "+obj.slots[i][1]);
		    }
		 }
	}
	public void accept()
	{
		 System.out.println("Accept");

	}
	public void ErrorNoGarage()
	{   
		System.out.println ("No Garage Available");
    }
	public void Notfound()
	{   
		System.out.println ("Not Found");
    }
}
