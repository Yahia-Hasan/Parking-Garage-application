package projest2;

public class Total_Income {
    public float totalincome;
    public int totalCars;

	public void totalcars()
	{
		totalCars+=1;
	}
	public void totalIncome(long n)
	{
		totalincome+=n;
	}

}
