package projest2;

public interface Select_configration {
   public int pick_slot(float width,float depth,parking_slots sl,Total_Income T);
}
