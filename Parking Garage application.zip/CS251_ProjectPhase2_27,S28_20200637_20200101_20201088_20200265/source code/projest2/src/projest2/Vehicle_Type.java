package projest2;

public enum Vehicle_Type {
	TransportVehicle,
	PrivateCar,
	Bus,
	SportCar, other
	}
