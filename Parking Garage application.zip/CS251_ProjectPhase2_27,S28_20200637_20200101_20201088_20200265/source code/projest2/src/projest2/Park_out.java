package projest2;

import java.time.Instant;

public class Park_out implements Time{
	public Instant setTime()
	{
		return Instant.now();
		
	}
}
