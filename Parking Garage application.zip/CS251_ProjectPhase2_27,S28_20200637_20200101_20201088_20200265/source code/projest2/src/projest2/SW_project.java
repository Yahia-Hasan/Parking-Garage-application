package projest2;

import java.time.Instant;
import java.util.Scanner;

public class SW_project {

	public static void main(String[] args) {
	    @SuppressWarnings("resource")
		Scanner myObj = new Scanner(System.in);
    	System.out.println ("Enter Owner or Driver (first time to Owner) ");

	    Select_configration way = null;
	    parking_slots s = null;
	    Display d=new Display();
	    Total_Income T=new Total_Income();

	    String actor;
	    actor = myObj.nextLine();
	    while(!actor.equals("Owner"))
	    {
	        d.ErrorNoGarage();
	        System.out.println ("Try Again");
            actor = myObj.nextLine();

	    }
	    
	    person owner=new Owner();
        System.out.println ("Enter Your Name ");
        String name = myObj.nextLine();
        owner.name(name);
        System.out.println ("Enter Your Password ");
        String pass = myObj.nextLine();
		owner.pass(pass);
	    s=new parking_slots();
	    
	    if (s.s==0)
	    {
	    	d.ErrorNoGarage();Runtime.getRuntime().exit(0);
	    }
	    
        System.out.println ("Select Configration (Best Fit ,First Slot )");
        String conf = myObj.nextLine();
        while(!conf.equals("Best Fit")&&!conf.equals("First Slot")){
        	 d.Notfound();
 	         System.out.println ("Try Again");
             conf = myObj.nextLine();

        }
        if(conf.equals("Best Fit")){
        way=new Best_fit_slot();}
        else if(conf.equals("First Slot"))
        {way=new First_slot();}
        System.out.println ("Do you Want to Display Slots ? yes or no");
        String Ans = myObj.nextLine();
        if(Ans.equals("yes")){
        d.availableSlots(s);}
        System.out.println ("Do you Want to Display Total Cars ? yes or no");
        Ans = myObj.nextLine();
        if(Ans.equals("yes")){
            System.out.println ("Total Cars ");
            System.out.println (T.totalCars);}
        System.out.println ("Do you Want to Display Total Income ? yes or no");
        Ans = myObj.nextLine();
        if(Ans.equals("yes")){
            System.out.println ("Total Income ");
            System.out.println (T.totalincome);}
        
	    
	    
	    
	    
	    String anser ="yes";
	    
	    
	    
	    
	    
	    while(true) {
    		Scanner myy = new Scanner(System.in);

            System.out.println ("Do you Want To Continue ?yes, no ");
            anser= myy.nextLine();
            if(!anser.equals("yes"))
            {
            	break;
            }
            else {System.out.println ("Enter Owner or Driver  ");
    	    actor = myy.nextLine();}
            
	    
	    if(actor.equals("Owner")){
        System.out.println ("Do you Want to Display Slots ? yes or no");
        Ans = myy.nextLine();
        if(Ans.equals("yes")){
        d.availableSlots(s);}
        System.out.println ("Do you Want to Display Total Cars ? yes or no");
        Ans = myy.nextLine();
        if(Ans.equals("yes")){
            System.out.println ("Total Cars ");
            System.out.println (T.totalCars);}
        System.out.println ("Do you Want to Display Total Income ? yes or no");
        Ans = myy.nextLine();
        if(Ans.equals("yes")){
            System.out.println ("Total Income ");
            System.out.println (T.totalincome);}
        
        
	    }
	    

       else if(actor.equals("Driver"))
	  {
        
		person driver=new Driver();
        System.out.println ("Enter Your Name ");
        name = myy.nextLine();
		driver.name(name);
        System.out.println ("Enter Your Password ");
        pass = myy.nextLine();
		driver.pass(pass);
		Vechile v=new Vechile();
        System.out.println ("Enter Type of car (PrivateCar ,TransportVehicle , SportCar , Bus ");
        name = myy.nextLine();
        Vehicle_Type t=Vehicle_Type.other;;
		if(name.equals("PrivateCar")){
	    t= Vehicle_Type.PrivateCar;}
		else if(name.equals("TransportVehicle")){
		t= Vehicle_Type.TransportVehicle;}
		else if(name.equals("Bus")){
		t= Vehicle_Type.Bus;}
		else if(name.equals("SportCar")){
		t= Vehicle_Type.SportCar;}
        System.out.println ("Enter Your Name of the vehicle");
        name = myy.nextLine();
        System.out.println ("Enter Your Number of the vehicle");
        int Number = myy.nextInt();
        System.out.println ("Enter Your Year of the vehicle");
        int Year = myy.nextInt();
        System.out.println ("Enter Your Width of the vehicle");
        int Width = myy.nextInt();
        System.out.println ("Enter Your Depth of the vehicle");
        int Depth = myy.nextInt();
		v.addNewVechile(name,Number,Year,Width,Depth,t);
		int k=way.pick_slot(v.getWidth(), v.getDepth(), s,T);
        if(k==0)
        {
        	System.out.println ("No Available Slots ");
        }
        else 
        {
    		Scanner my = new Scanner(System.in);

        	Instant st,e;
        	Time start=new Park_in();
        	st=start.setTime();
        	System.out.println ("Your Slot : "+k);
        	System.out.println ("Are You Leaving now? "); 
            String str ;
            str= my.nextLine();
            if (str.equals("yes")){
            Time end=new Park_out();
            e=end.setTime();
        	Parking_fees total=new Parking_fees();
        	System.out.println ("Your Fees : "+total.fees(st, e,s,T));
        	s.freeSlot(k-1);}}  }
}
	    }

	}
